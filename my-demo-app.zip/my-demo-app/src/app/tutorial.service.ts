import { Injectable } from '@angular/core';
import { Http,RequestOptions,Headers } from '@angular/http';
import 'rxjs/add/operator/toPromise';


@Injectable()
export class TutorialService {

  constructor(private httpService:Http) { 

  }

  public jsonHeaders(): Headers{
    let headers: Headers = new Headers();

    headers.append('Ocp-Apim-Subscription-Key', '0c21cedba5c1491d97fe5f18532e6743');
    headers.append('Content-Type', 'application/json');
  
    return headers;
  }

  list(){

    let options = new RequestOptions({headers: this.jsonHeaders()});

    return this.httpService.get(
      'http://msonic.azure-api.net/UtilService/v1/android',options)
      .toPromise()
      .then(response=>response.json())
      .catch(this.handleError);
  }

  private handleError(error:any){
      console.log("Ocurrio un error");
      return Promise.reject(error.message || error);
  }

  


}
