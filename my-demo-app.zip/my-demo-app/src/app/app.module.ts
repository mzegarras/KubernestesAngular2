import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { SecundarioComponent } from './secundario/secundario.component';
import { InicioComponent } from './inicio/inicio.component';
import { NosotrosComponent } from './nosotros/nosotros.component';
import { ContactenosComponent } from './contactenos/contactenos.component';
import { routing } from './app.routing';
import { TutorialComponent } from './tutorial/tutorial.component';

import { TutorialService } from './tutorial.service';

import { TipoCambioComponent } from './tipo-cambio/tipo-cambio.component';
import { TipoCambioService } from './tipo-cambio.service';

@NgModule({
  declarations: [
    AppComponent,
    SecundarioComponent,
    InicioComponent,
    NosotrosComponent,
    ContactenosComponent,
    TutorialComponent,
    TipoCambioComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing
  ],
  providers: [TutorialService,TipoCambioService],
  bootstrap: [AppComponent]
})
export class AppModule { }
