import { Component, OnInit } from '@angular/core';
import { TutorialService } from '../tutorial.service';


@Component({
  selector: 'app-tutorial',
  templateUrl: './tutorial.component.html',
  styleUrls: ['./tutorial.component.css']
})
export class TutorialComponent implements OnInit {

  tutoriales: Array<Object>;

  constructor(private tutorialService:TutorialService) { }

  ngOnInit() {
    this.listTutoriales();
  }

  listTutoriales(){
    this.tutorialService.list()
      .then(rs=>this.tutoriales =rs);
  }
}
