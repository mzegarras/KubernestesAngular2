import { TestBed, inject } from '@angular/core/testing';

import { TipoCambioService } from './tipo-cambio.service';

describe('TipoCambioService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TipoCambioService]
    });
  });

  it('should ...', inject([TipoCambioService], (service: TipoCambioService) => {
    expect(service).toBeTruthy();
  }));
});
