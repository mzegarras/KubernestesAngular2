import { Component, OnInit } from '@angular/core';
import { TipoCambioService } from '../tipo-cambio.service';

@Component({
  selector: 'app-tipo-cambio',
  templateUrl: './tipo-cambio.component.html',
  styleUrls: ['./tipo-cambio.component.css']
})
export class TipoCambioComponent implements OnInit {

  tipoCambio: any;

  constructor(private tipoCambioService:TipoCambioService) { }

  ngOnInit() {
    this.listTC();
  }

  listTC(){
    this.tipoCambioService.list()
      .then(rs=>
              {
                this.tipoCambio =rs;
              });
  }

}
