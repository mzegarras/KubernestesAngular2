import {Routes,RouterModule} from '@angular/router'

import {InicioComponent} from './inicio/inicio.component'
import {NosotrosComponent} from './nosotros/nosotros.component'
import {ContactenosComponent} from './contactenos/contactenos.component'
import {TutorialComponent} from './tutorial/tutorial.component'
import {TipoCambioComponent} from './tipo-cambio/tipo-cambio.component'

const APP_ROUTES: Routes = [
    {path:'inicio',component:InicioComponent},
    {path:'nosotros',component:NosotrosComponent},
    {path:'contactenos',component:ContactenosComponent},
    {path:'tutoriales',component:TutorialComponent},
    {path:'tipocambio',component:TipoCambioComponent}
];

export const routing = RouterModule.forRoot(APP_ROUTES);